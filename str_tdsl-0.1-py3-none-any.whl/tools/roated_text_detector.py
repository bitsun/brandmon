import cv2
from mmocr.apis import TextDetInferencer
from mmcv.ops import RoIAlignRotated
import torchvision 
import cv2
import numpy as np
import torch
class RotatedTextDetector:
    def __init__(self):
        self.rotated_detector = TextDetInferencer(model='DB_r18',weights="C:\\Users\\bliu\\.cache\\torch\\hub\\checkpoints\\dbnet_resnet18_fpnc_1200e_icdar2015_20220825_221614-7c0e94f2.pth")
    def detect(self, image):
        #check if image is np.array
        assert isinstance(image, np.ndarray)
        assert len(image.shape)==3 and image.shape[2]==3 and image.dtype==np.uint8
        result = self.rotated_detector(image)
        return result
    
if __name__ == '__main__':
    detector = RotatedTextDetector()
    image = cv2.imread("E:\\Data\\LogoWorkDir\\test\\screenshot-2022-09-22-at-12-28-41.png")
    result = detector.detect(image)
    pooler = RoIAlignRotated((150,300), spatial_scale=1.0, sampling_ratio=0,aligned=True)
    pooler1 = torchvision.ops.RoIAlign((32,64), spatial_scale=1.0, sampling_ratio=1, aligned=True)
    #convert image to torch tensor
    #swap axis of image from HWC to CHW
    image_tensor = torch.tensor(np.ascontiguousarray(image.transpose(2,0,1))).float().unsqueeze(0)
    
    rects = []
    angles = []
    for n,polygon in enumerate(result['predictions'][0]['polygons']):
        rect = cv2.minAreaRect(np.array(polygon).reshape(4,2).astype(np.int32))
        upright_rect = cv2.boundingRect(np.array(polygon).reshape(4,2).astype(np.int32))
        #get the bounding box of rect
        degree = rect[2]
        w = rect[1][0]
        h = rect[1][1]
        if w/h<1:
            #aspect ratio < 1, rotate 90 degree,and swap width and height
            degree = 90-degree
            radian = (degree)*np.pi/180
            w,h = h,w
        else:
            degree = -degree
            radian = (degree)*np.pi/180
            
        if abs(degree)<30 or rect[1][0]*rect[1][1]<300:
            continue
        angles.append((radian,upright_rect[2]/upright_rect[3],rect[1][0]/rect[1][1]))
        rects.append(np.array([0,rect[0][0],rect[0][1],w,h,radian]))
        #rects.append(np.array([0,rect[0],rect[1],rect[0]+rect[2],rect[1]+rect[3]]))
    rects = np.vstack(rects)
    rects = torch.tensor(rects).float()
    pooled_rects = pooler(image_tensor, rects)
    for n in range(pooled_rects.shape[0]):
        rectified_image = pooled_rects[n].permute(1,2,0).numpy()
        print(angles[n][0]*180/np.pi,angles[n][1],angles[n][2])
        cv2.imshow("roi",rectified_image.astype(np.uint8))
        cv2.waitKey(0)
    print("result")