import argparse
import sys,os
sys.path.append("./")
from maskrcnn_benchmark.config import cfg
from maskrcnn_benchmark.modeling.detector import build_detection_model
import torch
from torch import nn
from torchvision.transforms import functional as F
from maskrcnn_benchmark.structures.image_list import ImageList,to_image_list
from maskrcnn_benchmark.structures.bounding_box import BoxList
from maskrcnn_benchmark.utils.checkpoint import DetectronCheckpointer
import cv2
import numpy as np

class TextLogoRecognizer:
    """
    Scene Text Retrieval via Joint Text Detection and Similarity Learning 
    """
    def __init__(self,model_path,config_file,img_size=1280):
        cfg.merge_from_file(config_file)
        cfg.freeze()
        self.model = build_detection_model(cfg)
        checkpointer = DetectronCheckpointer(cfg, self.model, save_dir=cfg.OUTPUT_DIR)
        _ = checkpointer.load(model_path, use_latest=True)
        self.model.eval()
        
        #move the model to gpu
        if torch.cuda.is_available():
            self.device = "cuda"
            self.model.to(self.device)
        self.long_img_size = img_size
        if img_size % 32 != 0 :
            raise ValueError("img_size should be multiples of 32")
    
    def __preprocess(self,image):
        if not isinstance(image,np.ndarray) or image.dtype != np.uint8 or image.ndim != 3:
            raise ValueError("image should be a 3-channel uint8 image")
        ori_h, ori_w, _= image.shape
        if ori_h > ori_w:
            h = self.long_img_size
            w = int(ori_w*1.0/ori_h*h)
        w = self.long_img_size
        h = int(ori_h*1.0/ori_w*w)  
        pad_h = h if h%32==0 else (h//32+1)*32
        pad_w = w if w%32==0 else (w//32+1)*32
        new_image = cv2.resize(image, (pad_w, pad_h), interpolation=cv2.INTER_LINEAR)
        image_tensor = torch.from_numpy(new_image).permute(2,0,1).float()
        image_tensor = F.normalize(image_tensor, mean=[103.53, 116.28, 123.675], std=[57.375, 57.12, 58.395])
        image_tensor = image_tensor.unsqueeze(0)
        return image_tensor
    
    def extract_backbone_feature(self,image):
        """
        extract backbone feature from image
        """
        if isinstance(image,torch.Tensor):
            image_tensor = image
            if image_tensor.dim()!=4 or image_tensor.shape[0] != 1:
                raise ValueError("image tensor should have batch size 1")
        else:
            image_tensor = self.__preprocess(image)
        image_tensor = image_tensor.to(self.device)
        with torch.no_grad():
            features = self.model.neck(self.model.backbone(image_tensor))
        return image_tensor,features
    
    def detect_text(self,image,backbone_feature=None,image_size=None,conf_th=0.2):
        """
        This logo recognizer is has one text detection module embeded, it can be used to detect text in an image
        """
        if image_size is None:
            if not isinstance(image,np.ndarray) or image.dtype != np.uint8 or image.ndim != 3:
                raise ValueError("image size is none, input image should be a 3-channel uint8 image")
            image_w = image.shape[1]
            image_h = image.shape[0]
        else:
            image_w = image_size[0]
            image_h = image_size[1]
        if isinstance(image,torch.Tensor):
            image_tensor = image
            if image_tensor.shape[0] != 1:
                raise ValueError("image tensor should have batch size 1")
        else:
            image_tensor = self.__preprocess(image)
        if backbone_feature is None:
            backbone_feature = self.extract_backbone_feature(image_tensor)

        imagelist = to_image_list(image_tensor)
        bboxes, losses = self.model.decoder.detector(imagelist, backbone_feature[1:], None)
        bboxes = bboxes[0]
        scores = bboxes.get_field("scores")
        #box confidence score threshold is 0.2
        pos_idxs = torch.nonzero(scores>conf_th).view(-1)#75.43
        confident_text_bboxes = bboxes[pos_idxs]
        confident_text_bboxes = confident_text_bboxes.bbox.detach().cpu().numpy()
        #normalize the coordinates of confident text bboxes so that they are relative to the original image
        tensor_w = image_tensor.shape[3]
        tensor_h = image_tensor.shape[2]
        confident_text_bboxes[:,0] = confident_text_bboxes[:,0]*image_w/tensor_w
        confident_text_bboxes[:,1] = confident_text_bboxes[:,1]*image_h/tensor_h
        confident_text_bboxes[:,2] = confident_text_bboxes[:,2]*image_w/tensor_w
        confident_text_bboxes[:,3] = confident_text_bboxes[:,3]*image_h/tensor_h
        return confident_text_bboxes
    
    def extract_roi_feature(self,image,backbone_features=None,rois=None,image_size=None, normalize=True):
        """
        this is the image embedding branch mention in the original paper
        """
        if rois is None :
            return None
        if isinstance(image,torch.Tensor):
            image_tensor = image
            if image_tensor.shape[0] != 1:
                raise ValueError("image tensor should have batch size 1")
        else:
            image_tensor = self.__preprocess(image)
            #the shape of image tensor is 1x3xHxW, the shape of image is WxHx3
        
        tensor_w = image_tensor.shape[3]
        tensor_h = image_tensor.shape[2]

        if backbone_features is None:
            image_tensor,backbone_features = self.extract_backbone_feature(image_tensor)

        dim = self.model.decoder.head.image_embedding.rnn.embedding.out_features
        rec_features = backbone_features[:len(self.model.decoder.scales)]
        
        if image_size is None:
            if not isinstance(image,np.ndarray) or image.dtype != np.uint8 or image.ndim != 3:
                raise ValueError("image size is none, input image should be a 3-channel uint8 image")
            image_w = image.shape[1]
            image_h = image.shape[0]
        else:
            image_w = image_size[0]
            image_h = image_size[1]
        
        if isinstance(rois,torch.Tensor):
            #get torch tensor dimension
            if rois.dim()!=2 or rois[0].shape[1]!=4:
                raise ValueError("rois should be a Nx4 tensor")
            rois_tensor = rois[0]
        elif isinstance(rois,np.ndarray):
            if rois.ndim!=2 or rois.shape[1]!=4:
                raise ValueError("rois should be a Nx4 numpy array")
            rois_tensor = torch.from_numpy(rois).to(self.device)
        elif isinstance(rois,list):
            roi_asarray = np.zeros((len(rois),4),dtype=np.float32)
            for n,roi in enumerate(rois):
                if isinstance(roi,tuple):
                    if len(roi)!=4:
                        raise ValueError("each roi should be a 4 element tuple")
                    roi_asarray[n,:] = np.array(roi,dtype=np.float32)
                elif isinstance(roi,list):
                    if len(roi)!=4:
                        raise ValueError("each roi should be a 4 element list")
                    roi_asarray[n,:] = np.array(roi,dtype=np.float32)
                else:
                    raise ValueError("each roi should be a tuple or list")
            rois_tensor = torch.from_numpy(roi_asarray).to(self.device)
        else:
            if rois is not None:
                raise ValueError("rois should be a tensor, numpy array or list")
        if tensor_w!=image_w or tensor_h!=image_h:
            rois_tensor[:,0] = rois_tensor[:,0]*tensor_w/image_w
            rois_tensor[:,1] = rois_tensor[:,1]*tensor_h/image_h
            rois_tensor[:,2] = rois_tensor[:,2]*tensor_w/image_w
            rois_tensor[:,3] = rois_tensor[:,3]*tensor_h/image_h
        new_bboxes = BoxList(rois_tensor, (tensor_h,tensor_w), mode="xyxy")
        with torch.no_grad():
            rois = self.model.decoder.head.pooler(rec_features, [new_bboxes])
            imgs_embedding = self.model.decoder.head.image_embedding(rois)
            imgs_embedding = imgs_embedding.tanh().view(imgs_embedding.size(0),-1)
            if normalize:
                imgs_embedding_nor = nn.functional.normalize(imgs_embedding)
                result = imgs_embedding_nor.detach().cpu().numpy()
            else:
                result = imgs_embedding.detach().cpu().numpy()
        return result
    
    def extract_text_feature(self,input_words,normalize=True):
        if not isinstance(input_words,(list,tuple)):
            raise ValueError("texts should be a list or tuple")
        words = [torch.tensor(self.model.decoder.head.text_generator.label_map(word.lower())).long().to(self.device) for word in input_words]
        with torch.no_grad():
            words_embedding = self.model.decoder.head.word_embedding(words)
            words_embedding = words_embedding.tanh().view(words_embedding.size(0),-1)
            if normalize:
                words_embedding_nor = nn.functional.normalize(words_embedding)
                result = words_embedding_nor.detach().cpu().numpy()
            else:
                result = words_embedding.detach().cpu().numpy()
        return result
    def extract_rotated_roi_feature(self,org_image,rotated_rois):
        """
        extract feature from rotated roi regions
        Arguments
        ---------
        org_image: numpy array
            the original image as numpy ndarray
        rotated_rois: list of cv2 rotated rectangles. A opencv rotated rectangle is a tuple of 3 elements: (center_x,center_y,width,height,angle)
            the first element is (center_x, center_y), the 2nd element is (width,height), the 3rd element is angle
        """
        if not isinstance(org_image,np.ndarray) or org_image.dtype != np.uint8 or org_image.ndim != 3:
            raise ValueError("image should be a 3-channel uint8 image")
        if not isinstance(rotated_rois,list):
            raise ValueError("rotated_rois should be a list of cv2 rotated rectangles")
        if len(rotated_rois) == 0:
            return None
        #convert the rotated roi to a list of cv2 rectangles
        roi_features = []
        for rotated_roi in rotated_rois:
            center_x,center_y = rotated_roi[0]
            rect_width,rect_height = rotated_roi[1]
            angle = rotated_roi[2]
            rect_vertices = cv2.boxPoints(rotated_roi)
            if rect_width<rect_height:
                angle = angle + 90
                rect_width,rect_height = rect_height,rect_width
                rect = (rotated_roi[0],(rect_width,rect_height),angle)
                #now get the vertex of the new rotated rectangle
                rect_vertices = cv2.boxPoints(rect)
                dstTri = np.array( [rect_vertices[3], rect_vertices[0],rect_vertices[1]]).astype(np.float32)
            else:
                dstTri = np.array( [rect_vertices[1], rect_vertices[2],rect_vertices[3]]).astype(np.float32)
            #opencv affine transform
            srcTri = np.array( [[0, 0], [160, 0], [160, 40]] ).astype(np.float32)
            warp_mat = cv2.getAffineTransform(dstTri,srcTri)
            warped_roi_image = cv2.warpAffine(org_image, warp_mat,(160,40),cv2.WARP_INVERSE_MAP)
            rects = np.array([[0,0,warped_roi_image.shape[1],warped_roi_image.shape[0]]])
            features = self.extract_roi_feature(warped_roi_image,rois=rects,
                                                      image_size=(warped_roi_image.shape[1],warped_roi_image.shape[0]))
            roi_features.append(features[0])
        roi_features = np.vstack(roi_features)
        return roi_features
from mmocr.apis import TextDetInferencer
class RotatedTextDetector:
    def __init__(self):
        self.rotated_detector = TextDetInferencer(model='DB_r18',
                                                  weights="E:\\Data\\Model\\TextDetection\\dbnet_resnet18_fpnc_1200e_icdar2015_20220825_221614-7c0e94f2.pth",device="cpu")
    def detect(self, image):
        #check if image is np.array
        assert isinstance(image, np.ndarray)
        assert len(image.shape)==3 and image.shape[2]==3 and image.dtype==np.uint8
        result = self.rotated_detector(image)
        return result
    
if __name__ == '__main__':
    text_recognizer = TextLogoRecognizer("D:\\data\\datasets\\model_7709.pth",
                                         "D:\\code\\Research\\STR-TDSL-pytorch2.0\\configs\\evaluation.yaml",img_size=160)
    image = cv2.imread("E:\\Data\\LogoWorkDir\\test\\charal.jpg")
    ref_embedding = text_recognizer.extract_text_feature(["cleverland clinic"])
    detector = RotatedTextDetector()
    org_image = cv2.imread("E:\\Data\\LogoWorkDir\\test\\nba01.jpg")
    result = detector.detect(org_image)
    rotated_rects = []
    upright_rects = []
    for n,polygon in enumerate(result['predictions'][0]['polygons']):
        rect = cv2.minAreaRect(np.array(polygon).reshape(4,2).astype(np.int32))
        #get the bounding box of rect
        upright_rect = cv2.boundingRect(np.array(polygon).reshape(4,2).astype(np.int32))
        degree = rect[2]
        w = rect[1][0]
        h = rect[1][1]
        print("degree",degree,"w",w,"h",h)
        if (w>h and abs(degree)>30) or (w<h and abs(90-degree)>30):
            rotated_rects.append(rect)
            upright_rects.append(upright_rect)
    roi_features = text_recognizer.extract_rotated_roi_feature(org_image,rotated_rects)
    visualize_image = org_image.copy()
    for n,roi_feature in enumerate(roi_features):
        if np.dot(ref_embedding[0],roi_feature)>0.5:
            #draw rectangle
            rect = upright_rects[n]
            cv2.rectangle(visualize_image,(int(rect[0]),int(rect[1])),
                          (int(rect[0]+rect[2]),int(rect[1]+rect[3])),(0,255,0),2)
    cv2.imshow("image",visualize_image)
    cv2.waitKey(0)
        # rect_vertices = cv2.boxPoints(rect)
        # if w/h<1:
        #     #aspect ratio < 1, rotate 90 degree,and swap width and height
        #     degree = 90+degree
        #     w,h = h,w
        #     rect = (rect[0],(w,h),degree)
        #     #now get the vertex of the rotated rectangle
        #     rect_vertices = cv2.boxPoints(rect)
        #     # if abs(degree)<30 or rect[1][0]*rect[1][1]<300:
        #     #     continue
        #     dstTri = np.array( [rect_vertices[3], rect_vertices[0],rect_vertices[1]]).astype(np.float32)
        # else:
        #     dstTri = np.array( [rect_vertices[1], rect_vertices[2],rect_vertices[3]]).astype(np.float32)
        # #opencv affine transform
        # srcTri = np.array( [[0, 0], [160, 0], [160, 40]] ).astype(np.float32)
        
        # warp_mat = cv2.getAffineTransform(dstTri,srcTri)
        # warp_dst = cv2.warpAffine(org_image, warp_mat,(160,40),cv2.WARP_INVERSE_MAP)
        # cv2.imshow("image",warp_dst)
        # cv2.waitKey(0)
        # rects = np.array([[0,0,warp_dst.shape[1],warp_dst.shape[0]]])
        # roi_features,_ = text_recognizer.extract_roi_feature(warp_dst,rois=rects,image_size=(warp_dst.shape[1],warp_dst.shape[0]))
        # print(np.dot(ref_embedding[0],roi_features[0]))